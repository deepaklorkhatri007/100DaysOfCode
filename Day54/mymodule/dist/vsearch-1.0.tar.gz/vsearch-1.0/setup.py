from setuptools import setup

setup(
    name = 'vsearch',
    version = '1.0',
    desciption = 'The Head First Python Search Tools',
    author_email = 'deepaklorkhatri7@gmail.com',
    url = 'https://deepaklorkhatri007.github.io/Portfolio/',
    py_modules = ['vsearch']
)